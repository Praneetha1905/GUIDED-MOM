-- Seed health tips for pregnant women
INSERT INTO public.health_tips (user_type, week_range_start, week_range_end, category, title, content) VALUES
('pregnant', 1, 4, 'nutrition', 'Start Prenatal Vitamins', 'Begin taking prenatal vitamins with folic acid to support baby''s development and reduce birth defects.'),
('pregnant', 1, 4, 'wellness', 'Manage Morning Sickness', 'Try eating small, frequent meals and staying hydrated. Ginger tea and vitamin B6 may help.'),
('pregnant', 4, 8, 'exercise', 'Gentle Movement', 'Light walks and stretching are great for pregnancy. Avoid high-impact activities.'),
('pregnant', 8, 12, 'nutrition', 'Increase Calorie Intake', 'You need about 300 extra calories per day. Focus on nutrient-dense foods.'),
('pregnant', 20, 24, 'wellness', 'Monitor Baby Kicks', 'Start noticing baby''s movement patterns. Report any decrease in kicks to your doctor.'),
('pregnant', 24, 28, 'health', 'Glucose Screening', 'This test screens for gestational diabetes. Follow your doctor''s instructions.'),
('pregnant', 32, 36, 'wellness', 'Pelvic Floor Exercises', 'Kegel exercises can help with delivery and postpartum recovery.'),
('pregnant', 36, 40, 'health', 'Prepare for Labor', 'Take childbirth classes and practice relaxation techniques for labor.'),
('new_mother', 0, 2, 'recovery', 'Rest and Recovery', 'Your body needs time to heal. Sleep when the baby sleeps and accept help from family.'),
('new_mother', 0, 2, 'feeding', 'Breastfeeding Support', 'If breastfeeding, seek support from lactation consultants. It''s normal if it takes time.'),
('new_mother', 1, 4, 'mental_health', 'Watch for Postpartum Depression', 'If you feel persistently sad or anxious, reach out to your healthcare provider immediately.'),
('new_mother', 2, 6, 'wellness', 'Gentle Movement', 'Light walks and pelvic floor exercises can help with recovery. Avoid heavy exercise for 6 weeks.'),
('new_mother', 4, 8, 'nutrition', 'Nourish Your Body', 'Eat regular, balanced meals to support recovery and milk production if breastfeeding.'),
('new_mother', 8, 12, 'exercise', 'Resume Exercise', 'After clearance from your doctor, gradually increase physical activity.'),
('new_mother', 12, 26, 'wellness', 'Prioritize Sleep and Self-Care', 'Make sleep a priority and engage in activities that bring you joy.');
