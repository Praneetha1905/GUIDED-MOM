-- Create profiles table for user information
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text,
  user_type text CHECK (user_type IN ('pregnant', 'new_mother')),
  avatar_url text,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()),
  updated_at timestamp with time zone DEFAULT timezone('utc'::text, now())
);

-- Create pregnancy tracker table
CREATE TABLE IF NOT EXISTS public.pregnancy_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  weeks_pregnant integer,
  due_date date,
  last_checkup date,
  notes text,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()),
  updated_at timestamp with time zone DEFAULT timezone('utc'::text, now())
);

-- Create postpartum tracking table
CREATE TABLE IF NOT EXISTS public.postpartum_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  weeks_postpartum integer,
  baby_dob date,
  feeding_type text CHECK (feeding_type IN ('breast', 'formula', 'mixed')),
  mood_level integer CHECK (mood_level >= 1 AND mood_level <= 10),
  notes text,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()),
  updated_at timestamp with time zone DEFAULT timezone('utc'::text, now())
);

-- Create health tips table
CREATE TABLE IF NOT EXISTS public.health_tips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_type text CHECK (user_type IN ('pregnant', 'new_mother')),
  week_range_start integer,
  week_range_end integer,
  category text,
  title text NOT NULL,
  content text NOT NULL,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now())
);

-- Create reminders table
CREATE TABLE IF NOT EXISTS public.reminders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  reminder_date date NOT NULL,
  reminder_time time,
  reminder_type text CHECK (reminder_type IN ('checkup', 'medication', 'exercise', 'custom')),
  is_completed boolean DEFAULT false,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()),
  updated_at timestamp with time zone DEFAULT timezone('utc'::text, now())
);

-- Create chat messages table for AI assistant
CREATE TABLE IF NOT EXISTS public.chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role text CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now())
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pregnancy_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.postpartum_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.health_tips ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reminders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for profiles
CREATE POLICY "profiles_select_own" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "profiles_delete_own" ON public.profiles FOR DELETE USING (auth.uid() = id);

-- Create RLS policies for pregnancy_tracking
CREATE POLICY "pregnancy_tracking_select_own" ON public.pregnancy_tracking FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "pregnancy_tracking_insert_own" ON public.pregnancy_tracking FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "pregnancy_tracking_update_own" ON public.pregnancy_tracking FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "pregnancy_tracking_delete_own" ON public.pregnancy_tracking FOR DELETE USING (auth.uid() = user_id);

-- Create RLS policies for postpartum_tracking
CREATE POLICY "postpartum_tracking_select_own" ON public.postpartum_tracking FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "postpartum_tracking_insert_own" ON public.postpartum_tracking FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "postpartum_tracking_update_own" ON public.postpartum_tracking FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "postpartum_tracking_delete_own" ON public.postpartum_tracking FOR DELETE USING (auth.uid() = user_id);

-- Create RLS policies for health_tips (public read)
CREATE POLICY "health_tips_select_all" ON public.health_tips FOR SELECT USING (true);

-- Create RLS policies for reminders
CREATE POLICY "reminders_select_own" ON public.reminders FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "reminders_insert_own" ON public.reminders FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "reminders_update_own" ON public.reminders FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "reminders_delete_own" ON public.reminders FOR DELETE USING (auth.uid() = user_id);

-- Create RLS policies for chat_messages
CREATE POLICY "chat_messages_select_own" ON public.chat_messages FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "chat_messages_insert_own" ON public.chat_messages FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "chat_messages_delete_own" ON public.chat_messages FOR DELETE USING (auth.uid() = user_id);

-- Create trigger for auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email)
  VALUES (new.id, new.email)
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();
