"use server"

import { generateText, streamText } from "ai"
import { createStreamableValue } from "@ai-sdk/rsc"

export async function generateHealthAssistantResponse(prompt: string, userType: "pregnant" | "new_mother") {
  const systemPrompt = `You are a compassionate and knowledgeable health assistant specializing in ${
    userType === "pregnant" ? "pregnancy support and maternal health" : "postpartum care and recovery"
  }. 

Your role is to provide evidence-based information, practical advice, and emotional support to mothers. Always:
- Be empathetic and non-judgmental
- Provide accurate, evidence-based information
- Suggest consulting healthcare providers for serious concerns
- Personalize responses based on the user's stage
- Use simple, clear language
- Never provide medical diagnosis
- Encourage healthy habits and self-care

Remember that you're supporting a vulnerable time in a woman's life. Be supportive, reassuring, and practical.`

  const { text } = await generateText({
    model: "openai/gpt-5-mini",
    system: systemPrompt,
    prompt,
    maxOutputTokens: 1000,
  })

  return text
}

export async function streamHealthAssistantResponse(prompt: string, userType: "pregnant" | "new_mother") {
  const systemPrompt = `You are a compassionate and knowledgeable health assistant specializing in ${
    userType === "pregnant" ? "pregnancy support and maternal health" : "postpartum care and recovery"
  }. 

Your role is to provide evidence-based information, practical advice, and emotional support to mothers. Always:
- Be empathetic and non-judgmental
- Provide accurate, evidence-based information
- Suggest consulting healthcare providers for serious concerns
- Personalize responses based on the user's stage
- Use simple, clear language
- Never provide medical diagnosis
- Encourage healthy habits and self-care

Remember that you're supporting a vulnerable time in a woman's life. Be supportive, reassuring, and practical.`

  const result = streamText({
    model: "openai/gpt-5-mini",
    system: systemPrompt,
    prompt,
    maxOutputTokens: 2000,
  })

  const stream = createStreamableValue(result.textStream)
  return stream.value
}
