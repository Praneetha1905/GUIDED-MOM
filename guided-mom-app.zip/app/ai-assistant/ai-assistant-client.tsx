"use client"

import { useRef, useEffect } from "react"
import type { User } from "@supabase/supabase-js"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { MessageCircle, Send, ArrowLeft, Loader } from "lucide-react"
import Link from "next/link"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useChat } from "@ai-sdk/react"

interface Profile {
  id: string
  email: string
  full_name: string | null
  user_type: "pregnant" | "new_mother"
  avatar_url: string | null
}

interface AIAssistantClientProps {
  user: User
  profile: Profile
}

export default function AIAssistantClient({ user, profile }: AIAssistantClientProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: "/api/chat",
    headers: {
      "X-User-Type": profile.user_type,
      "X-User-Email": user.email || "",
    },
  })

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card shadow-sm">
        <div className="mx-auto max-w-3xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/dashboard">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ArrowLeft className="h-4 w-4" />
                  Back
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <MessageCircle className="h-6 w-6 text-primary" />
                <h1 className="text-2xl font-bold text-foreground">AI Health Assistant</h1>
              </div>
            </div>
          </div>
          <p className="text-sm text-muted-foreground mt-2 ml-12">
            Ask questions about your {profile.user_type === "pregnant" ? "pregnancy" : "postpartum"} journey
          </p>
        </div>
      </header>

      {/* Chat Container */}
      <main className="mx-auto max-w-3xl px-4 py-8 sm:px-6 lg:px-8 h-[calc(100vh-180px)] flex flex-col">
        <Card className="flex flex-col h-full border-primary/20">
          {/* Messages Area */}
          <ScrollArea className="flex-1 p-6">
            <div className="space-y-4">
              {messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-96 text-center">
                  <MessageCircle className="h-12 w-12 text-muted-foreground mb-4" />
                  <h2 className="text-xl font-semibold text-foreground mb-2">Welcome to Your Health Assistant</h2>
                  <p className="text-muted-foreground max-w-md">
                    Ask me anything about your {profile.user_type === "pregnant" ? "pregnancy" : "postpartum"} journey.
                    I'm here to provide evidence-based guidance and support.
                  </p>
                </div>
              ) : (
                <>
                  {messages.map((message, index) => (
                    <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                          message.role === "user"
                            ? "bg-primary text-primary-foreground rounded-br-none"
                            : "bg-muted text-foreground rounded-bl-none"
                        }`}
                      >
                        <p className="text-sm">{message.content}</p>
                      </div>
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-muted text-foreground px-4 py-3 rounded-lg rounded-bl-none flex items-center gap-2">
                        <Loader className="h-4 w-4 animate-spin" />
                        <p className="text-sm">Thinking...</p>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </>
              )}
            </div>
          </ScrollArea>

          {/* Input Area */}
          <CardContent className="border-t border-border p-4">
            <form onSubmit={handleSubmit} className="flex gap-2">
              <Input
                value={input}
                onChange={handleInputChange}
                placeholder="Type your question here..."
                disabled={isLoading}
                className="flex-1 bg-input"
              />
              <Button
                type="submit"
                disabled={isLoading || !input.trim()}
                size="sm"
                className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <Send className="h-4 w-4" />
                Send
              </Button>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
