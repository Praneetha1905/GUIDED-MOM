import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import AIAssistantClient from "./ai-assistant-client"

export const metadata = {
  title: "AI Health Assistant - Guided Mom",
  description: "Chat with your AI health assistant for pregnancy and postpartum support.",
}

export default async function AIAssistantPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile?.user_type) {
    redirect("/auth/select-type")
  }

  return <AIAssistantClient user={user} profile={profile} />
}
