import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Heart, Calendar, MessageCircle, CheckCircle } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted">
      {/* Hero Section */}
      <div className="relative px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <div className="mb-6 inline-block rounded-full bg-primary/10 px-4 py-2">
            <p className="text-sm font-medium text-primary">Your Journey, Your Support</p>
          </div>

          <h1 className="mb-6 text-4xl font-bold tracking-tight text-foreground sm:text-5xl">Welcome to Guided Mom</h1>

          <p className="mb-8 text-lg text-muted-foreground">
            A compassionate companion for your pregnancy and postpartum journey. Track your progress, receive
            personalized health tips, and connect with an AI health assistant.
          </p>

          <div className="flex flex-col gap-4 sm:flex-row justify-center">
            <Link href="/auth/sign-up">
              <Button size="lg" className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-primary-foreground">
                Get Started
              </Button>
            </Link>
            <Link href="/auth/login">
              <Button size="lg" variant="outline" className="w-full sm:w-auto bg-transparent">
                Sign In
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="relative px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-5xl">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold text-foreground">How Guided Mom Helps</h2>
            <p className="text-muted-foreground">Everything you need for a supported motherhood journey</p>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <Card className="border-primary/20 bg-card hover:shadow-lg transition-shadow">
              <CardHeader>
                <Heart className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Personalized Tracking</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Track your pregnancy weeks, baby movements, or postpartum recovery with easy-to-use tools designed for
                  you.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-accent/20 bg-card hover:shadow-lg transition-shadow">
              <CardHeader>
                <Calendar className="h-8 w-8 text-accent mb-2" />
                <CardTitle>Smart Reminders</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Never miss important appointments, medications, or wellness activities with personalized reminders.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-secondary/20 bg-card hover:shadow-lg transition-shadow">
              <CardHeader>
                <CheckCircle className="h-8 w-8 text-secondary mb-2" />
                <CardTitle>Health Tips</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Receive evidence-based health tips tailored to your specific week and stage of motherhood.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-primary/20 bg-card hover:shadow-lg transition-shadow">
              <CardHeader>
                <MessageCircle className="h-8 w-8 text-primary mb-2" />
                <CardTitle>AI Health Assistant</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Chat with our AI health assistant for answers to your questions anytime, day or night.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="relative px-4 py-16 sm:px-6 lg:px-8 bg-primary/5">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="mb-4 text-2xl font-bold text-foreground">Ready to start your guided journey?</h2>
          <p className="mb-8 text-muted-foreground">
            Join thousands of mothers finding support and confidence in their motherhood journey.
          </p>
          <Link href="/auth/sign-up">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
              Create Your Account
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
