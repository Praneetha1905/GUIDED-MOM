import { openai } from "@ai-sdk/openai"
import { convertToCoreMessages, streamText } from "ai"

export const maxDuration = 30

export async function POST(req: Request) {
  const { messages } = await req.json()

  // Get user type from headers for context
  const userType = (req.headers.get("x-user-type") as "pregnant" | "new_mother") || "pregnant"

  const systemPrompt = `You are a compassionate and knowledgeable health assistant specializing in ${
    userType === "pregnant" ? "pregnancy support and maternal health" : "postpartum care and recovery"
  }. 

Your role is to provide evidence-based information, practical advice, and emotional support to mothers. Always:
- Be empathetic and non-judgmental
- Provide accurate, evidence-based information
- Suggest consulting healthcare providers for serious concerns
- Personalize responses based on the user's stage
- Use simple, clear language
- Never provide medical diagnosis
- Encourage healthy habits and self-care

Remember that you're supporting a vulnerable time in a woman's life. Be supportive, reassuring, and practical.`

  const result = streamText({
    model: openai("gpt-4o-mini"),
    system: systemPrompt,
    messages: convertToCoreMessages(messages),
  })

  return result.toAIStreamResponse()
}
