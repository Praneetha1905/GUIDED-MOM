"use client"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useRouter } from "next/navigation"
import { useState } from "react"
import { Heart, Baby } from "lucide-react"

export default function SelectTypePage() {
  const [selectedType, setSelectedType] = useState<"pregnant" | "new_mother" | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  const handleContinue = async () => {
    if (!selectedType) return

    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        setError("You must be logged in")
        router.push("/auth/login")
        return
      }

      const { error: updateError } = await supabase
        .from("profiles")
        .update({ user_type: selectedType })
        .eq("id", user.id)

      if (updateError) throw updateError

      router.push("/dashboard")
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-svh bg-gradient-to-b from-background to-muted flex items-center justify-center p-6">
      <div className="w-full max-w-2xl">
        <div className="mb-12 text-center">
          <h1 className="mb-4 text-4xl font-bold text-foreground">Tell Us About Your Journey</h1>
          <p className="text-lg text-muted-foreground">
            We&apos;ll personalize your experience based on your current stage
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card
            className={`cursor-pointer border-2 transition-all hover:shadow-lg ${
              selectedType === "pregnant"
                ? "border-primary bg-primary/5"
                : "border-border bg-card hover:border-primary/50"
            }`}
            onClick={() => setSelectedType("pregnant")}
          >
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <div className="rounded-full bg-primary/10 p-4">
                  <Heart className="h-8 w-8 text-primary" />
                </div>
              </div>
              <CardTitle>Expecting a Baby</CardTitle>
              <CardDescription>I&apos;m currently pregnant</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground text-center">
                Track your pregnancy weeks, receive week-by-week health tips, manage appointments, and connect with
                resources tailored to expecting mothers.
              </p>
            </CardContent>
          </Card>

          <Card
            className={`cursor-pointer border-2 transition-all hover:shadow-lg ${
              selectedType === "new_mother"
                ? "border-accent bg-accent/5"
                : "border-border bg-card hover:border-accent/50"
            }`}
            onClick={() => setSelectedType("new_mother")}
          >
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <div className="rounded-full bg-accent/10 p-4">
                  <Baby className="h-8 w-8 text-accent" />
                </div>
              </div>
              <CardTitle>New Mother</CardTitle>
              <CardDescription>I&apos;ve recently given birth</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground text-center">
                Track your postpartum recovery, baby milestones, feeding journey, and receive postpartum-specific health
                guidance and support.
              </p>
            </CardContent>
          </Card>
        </div>

        {error && <p className="mt-6 text-center text-sm text-destructive">{error}</p>}

        <div className="mt-8 flex justify-center">
          <Button
            size="lg"
            onClick={handleContinue}
            disabled={!selectedType || isLoading}
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-12"
          >
            {isLoading ? "Continuing..." : "Continue"}
          </Button>
        </div>
      </div>
    </div>
  )
}
