"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { Calendar, Heart, AlertCircle } from "lucide-react"

interface PregnancyData {
  id?: string
  weeks_pregnant: number
  due_date: string
  last_checkup: string
  notes: string
}

export default function PregnancyTracker({ userId }: { userId: string }) {
  const [data, setData] = useState<PregnancyData>({
    weeks_pregnant: 0,
    due_date: "",
    last_checkup: "",
    notes: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [daysUntilDue, setDaysUntilDue] = useState(0)
  const [trimester, setTrimester] = useState("")

  useEffect(() => {
    loadData()
  }, [userId])

  useEffect(() => {
    if (data.due_date) {
      const today = new Date()
      const dueDate = new Date(data.due_date)
      const diff = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
      setDaysUntilDue(diff)
    }

    if (data.weeks_pregnant > 0) {
      if (data.weeks_pregnant <= 13) setTrimester("First Trimester")
      else if (data.weeks_pregnant <= 26) setTrimester("Second Trimester")
      else setTrimester("Third Trimester")
    }
  }, [data])

  const loadData = async () => {
    const supabase = createClient()
    const { data: record } = await supabase
      .from("pregnancy_tracking")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(1)
      .single()

    if (record) {
      setData(record)
    }
  }

  const handleSave = async () => {
    setIsLoading(true)
    setError(null)
    setSuccess(false)

    try {
      const supabase = createClient()

      if (data.id) {
        const { error: updateError } = await supabase.from("pregnancy_tracking").update(data).eq("id", data.id)

        if (updateError) throw updateError
      } else {
        const { error: insertError } = await supabase.from("pregnancy_tracking").insert({
          ...data,
          user_id: userId,
        })

        if (insertError) throw insertError
      }

      setSuccess(true)
      await loadData()
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const progressPercent = Math.min((data.weeks_pregnant / 40) * 100, 100)

  return (
    <div className="space-y-6">
      {/* Progress Overview */}
      {data.weeks_pregnant > 0 && (
        <div className="grid gap-4 md:grid-cols-3">
          <Card className="border-primary/20 bg-card">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary">{data.weeks_pregnant}</div>
                <p className="text-sm text-muted-foreground mt-1">Weeks Pregnant</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-accent/20 bg-card">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-accent">{daysUntilDue}</div>
                <p className="text-sm text-muted-foreground mt-1">Days Until Due Date</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-secondary/20 bg-card">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-lg font-semibold text-secondary">{trimester}</div>
                <p className="text-sm text-muted-foreground mt-1">Current Stage</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Progress Bar */}
      {data.weeks_pregnant > 0 && (
        <Card className="border-primary/20">
          <CardContent className="pt-6">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <p className="text-sm font-medium">Pregnancy Progress</p>
                <p className="text-sm text-muted-foreground">{Math.round(progressPercent)}%</p>
              </div>
              <Progress value={progressPercent} className="h-3" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Form */}
      <Card className="border-primary/20">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Heart className="h-5 w-5 text-primary" />
            <div>
              <CardTitle>Pregnancy Tracking</CardTitle>
              <CardDescription>Track your pregnancy progress and milestones</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="grid gap-2">
                <Label htmlFor="weeks">Weeks Pregnant</Label>
                <Input
                  id="weeks"
                  type="number"
                  min="0"
                  max="42"
                  value={data.weeks_pregnant}
                  onChange={(e) =>
                    setData({
                      ...data,
                      weeks_pregnant: Number.parseInt(e.target.value) || 0,
                    })
                  }
                  className="bg-background"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="due-date" className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Due Date
                </Label>
                <Input
                  id="due-date"
                  type="date"
                  value={data.due_date}
                  onChange={(e) =>
                    setData({
                      ...data,
                      due_date: e.target.value,
                    })
                  }
                  className="bg-background"
                />
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="last-checkup">Last Checkup</Label>
              <Input
                id="last-checkup"
                type="date"
                value={data.last_checkup}
                onChange={(e) =>
                  setData({
                    ...data,
                    last_checkup: e.target.value,
                  })
                }
                className="bg-background"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="notes">Notes & Observations</Label>
              <Textarea
                id="notes"
                placeholder="Add any notes about your pregnancy, concerns, symptoms, or observations..."
                value={data.notes}
                onChange={(e) =>
                  setData({
                    ...data,
                    notes: e.target.value,
                  })
                }
                className="min-h-24 bg-background"
              />
            </div>

            {data.weeks_pregnant > 0 && daysUntilDue < 0 && (
              <div className="flex gap-3 p-4 bg-destructive/10 border border-destructive/30 rounded-lg">
                <AlertCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
                <div className="text-sm text-destructive">
                  <p className="font-medium">Due date has passed</p>
                  <p>Please contact your healthcare provider</p>
                </div>
              </div>
            )}

            {error && <p className="text-sm text-destructive">{error}</p>}
            {success && <p className="text-sm text-green-600">Pregnancy data saved successfully!</p>}

            <Button onClick={handleSave} disabled={isLoading} className="w-full bg-primary hover:bg-primary/90">
              {isLoading ? "Saving..." : "Save Progress"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Pregnancy Tips */}
      {data.weeks_pregnant > 0 && (
        <Card className="border-secondary/20 bg-gradient-to-br from-secondary/10 to-transparent">
          <CardHeader>
            <CardTitle className="text-lg">Week {data.weeks_pregnant} Highlights</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              {data.weeks_pregnant <= 13 && (
                <>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Morning sickness is common. Try frequent small meals.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Take prenatal vitamins with folic acid daily.</span>
                  </li>
                </>
              )}
              {data.weeks_pregnant > 13 && data.weeks_pregnant <= 26 && (
                <>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Energy levels typically improve in the second trimester.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>You should start feeling baby movements soon.</span>
                  </li>
                </>
              )}
              {data.weeks_pregnant > 26 && (
                <>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Practice relaxation techniques for labor preparation.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary">•</span>
                    <span>Monitor baby kicks daily - report any changes.</span>
                  </li>
                </>
              )}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
