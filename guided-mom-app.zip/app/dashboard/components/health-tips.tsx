"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Lightbulb } from "lucide-react"

interface HealthTip {
  id: string
  title: string
  content: string
  category: string
  week_range_start: number
  week_range_end: number
}

export default function HealthTips({ userType }: { userType: "pregnant" | "new_mother" }) {
  const [tips, setTips] = useState<HealthTip[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedCategory, setSelectedCategory] = useState("all")

  useEffect(() => {
    loadTips()
  }, [userType])

  const loadTips = async () => {
    const supabase = createClient()
    const { data } = await supabase.from("health_tips").select("*").eq("user_type", userType).order("week_range_start")

    setTips(data || [])
    setIsLoading(false)
  }

  const categories = ["all", ...new Set(tips.map((t) => t.category))]
  const filteredTips = selectedCategory === "all" ? tips : tips.filter((t) => t.category === selectedCategory)

  return (
    <div className="space-y-6">
      <Card className="border-secondary/20">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-secondary" />
            <div>
              <CardTitle>Personalized Health Tips</CardTitle>
              <CardDescription>Evidence-based guidance for your stage</CardDescription>
            </div>
          </div>
        </CardHeader>
      </Card>

      {!isLoading && (
        <div>
          <Tabs defaultValue="all" onValueChange={setSelectedCategory} className="w-full">
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-5 bg-muted">
              {categories.map((cat) => (
                <TabsTrigger key={cat} value={cat} className="capitalize">
                  {cat}
                </TabsTrigger>
              ))}
            </TabsList>

            <TabsContent value={selectedCategory} className="space-y-4 mt-6">
              {filteredTips.length > 0 ? (
                <div className="grid gap-4">
                  {filteredTips.map((tip) => (
                    <Card key={tip.id} className="border-secondary/10 bg-card hover:shadow-md transition-shadow">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle className="text-lg">{tip.title}</CardTitle>
                            <CardDescription>
                              Week {tip.week_range_start}-{tip.week_range_end} • {tip.category}
                            </CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-foreground">{tip.content}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="border-border bg-card">
                  <CardContent className="pt-6">
                    <p className="text-center text-muted-foreground">No tips available for this category yet.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  )
}
