"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Baby, Smile, TrendingUp } from "lucide-react"

interface PostpartumData {
  id?: string
  weeks_postpartum: number
  baby_dob: string
  feeding_type: string
  mood_level: number
  notes: string
}

export default function PostpartumTracker({ userId }: { userId: string }) {
  const [data, setData] = useState<PostpartumData>({
    weeks_postpartum: 0,
    baby_dob: "",
    feeding_type: "breast",
    mood_level: 5,
    notes: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [babyAgeText, setBabyAgeText] = useState("")

  useEffect(() => {
    loadData()
  }, [userId])

  useEffect(() => {
    if (data.baby_dob) {
      const today = new Date()
      const dob = new Date(data.baby_dob)
      const ageInDays = Math.floor((today.getTime() - dob.getTime()) / (1000 * 60 * 60 * 24))
      const weeksAge = Math.floor(ageInDays / 7)
      const daysAge = ageInDays % 7

      if (ageInDays === 0) {
        setBabyAgeText("Born today!")
      } else if (ageInDays < 7) {
        setBabyAgeText(`${ageInDays} day${ageInDays !== 1 ? "s" : ""} old`)
      } else {
        setBabyAgeText(`${weeksAge} week${weeksAge !== 1 ? "s" : ""} and ${daysAge} day${daysAge !== 1 ? "s" : ""} old`)
      }
    }
  }, [data.baby_dob])

  const loadData = async () => {
    const supabase = createClient()
    const { data: record } = await supabase
      .from("postpartum_tracking")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(1)
      .single()

    if (record) {
      setData(record)
    }
  }

  const handleSave = async () => {
    setIsLoading(true)
    setError(null)
    setSuccess(false)

    try {
      const supabase = createClient()

      if (data.id) {
        const { error: updateError } = await supabase.from("postpartum_tracking").update(data).eq("id", data.id)

        if (updateError) throw updateError
      } else {
        const { error: insertError } = await supabase.from("postpartum_tracking").insert({
          ...data,
          user_id: userId,
        })

        if (insertError) throw insertError
      }

      setSuccess(true)
      await loadData()
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Baby Age Overview */}
      {data.baby_dob && (
        <div className="grid gap-4 md:grid-cols-3">
          <Card className="border-accent/20 bg-card">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-accent">{babyAgeText}</div>
                <p className="text-sm text-muted-foreground mt-1">Baby's Age</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-secondary/20 bg-card">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-secondary">{data.mood_level}</div>
                <p className="text-sm text-muted-foreground mt-1">Your Mood (1-10)</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-primary/20 bg-card">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-lg font-semibold text-primary capitalize">{data.feeding_type} Feeding</div>
                <p className="text-sm text-muted-foreground mt-1">Feeding Method</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Main Form */}
      <Card className="border-accent/20">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Baby className="h-5 w-5 text-accent" />
            <div>
              <CardTitle>Postpartum Recovery</CardTitle>
              <CardDescription>Track your recovery and baby&apos;s milestones</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="grid gap-2">
                <Label htmlFor="weeks">Weeks Postpartum</Label>
                <Input
                  id="weeks"
                  type="number"
                  min="0"
                  value={data.weeks_postpartum}
                  onChange={(e) =>
                    setData({
                      ...data,
                      weeks_postpartum: Number.parseInt(e.target.value) || 0,
                    })
                  }
                  className="bg-background"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="baby-dob">Baby&apos;s Date of Birth</Label>
                <Input
                  id="baby-dob"
                  type="date"
                  value={data.baby_dob}
                  onChange={(e) =>
                    setData({
                      ...data,
                      baby_dob: e.target.value,
                    })
                  }
                  className="bg-background"
                />
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="feeding">Feeding Type</Label>
              <Select value={data.feeding_type} onValueChange={(value) => setData({ ...data, feeding_type: value })}>
                <SelectTrigger className="bg-background">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="breast">Breastfeeding</SelectItem>
                  <SelectItem value="formula">Formula Feeding</SelectItem>
                  <SelectItem value="mixed">Mixed Feeding</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-4">
              <div className="flex items-center gap-2">
                <Smile className="h-4 w-4 text-secondary" />
                <Label>How are you feeling? (1-10)</Label>
              </div>
              <div className="space-y-3">
                <Slider
                  value={[data.mood_level]}
                  onValueChange={(value) =>
                    setData({
                      ...data,
                      mood_level: value[0],
                    })
                  }
                  min={1}
                  max={10}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Struggling</span>
                  <span className="font-semibold text-foreground">{data.mood_level}/10</span>
                  <span>Excellent</span>
                </div>
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="notes">Recovery Notes</Label>
              <Textarea
                id="notes"
                placeholder="Add notes about your recovery, baby's progress, feeding success, sleep patterns, concerns..."
                value={data.notes}
                onChange={(e) =>
                  setData({
                    ...data,
                    notes: e.target.value,
                  })
                }
                className="min-h-24 bg-background"
              />
            </div>

            {error && <p className="text-sm text-destructive">{error}</p>}
            {success && <p className="text-sm text-green-600">Postpartum data saved successfully!</p>}

            <Button onClick={handleSave} disabled={isLoading} className="w-full bg-primary hover:bg-primary/90">
              {isLoading ? "Saving..." : "Save Progress"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recovery Tips */}
      {data.weeks_postpartum > 0 && (
        <Card className="border-accent/20 bg-gradient-to-br from-accent/10 to-transparent">
          <CardHeader>
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-accent" />
              <CardTitle className="text-lg">Week {data.weeks_postpartum} Recovery Tips</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              {data.weeks_postpartum < 2 && (
                <>
                  <li className="flex gap-2">
                    <span className="text-accent">•</span>
                    <span>Rest as much as possible. Your body is healing.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent">•</span>
                    <span>Avoid heavy lifting and strenuous activity.</span>
                  </li>
                </>
              )}
              {data.weeks_postpartum >= 2 && data.weeks_postpartum < 6 && (
                <>
                  <li className="flex gap-2">
                    <span className="text-accent">•</span>
                    <span>Gentle walking is beneficial for recovery.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent">•</span>
                    <span>Continue pelvic floor exercises as tolerated.</span>
                  </li>
                </>
              )}
              {data.weeks_postpartum >= 6 && (
                <>
                  <li className="flex gap-2">
                    <span className="text-accent">•</span>
                    <span>After doctor clearance, you can resume exercise gradually.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent">•</span>
                    <span>Focus on rebuilding core strength.</span>
                  </li>
                </>
              )}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
