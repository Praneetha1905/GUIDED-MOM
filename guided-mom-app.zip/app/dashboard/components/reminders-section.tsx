"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Calendar, Clock, Trash2 } from "lucide-react"

interface Reminder {
  id: string
  title: string
  description: string | null
  reminder_date: string
  reminder_time: string | null
  reminder_type: string
  is_completed: boolean
}

export default function RemindersSection({ userId }: { userId: string }) {
  const [reminders, setReminders] = useState<Reminder[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    reminder_date: "",
    reminder_time: "",
    reminder_type: "custom",
  })

  useEffect(() => {
    loadReminders()
  }, [userId])

  const loadReminders = async () => {
    const supabase = createClient()
    const { data } = await supabase
      .from("reminders")
      .select("*")
      .eq("user_id", userId)
      .order("reminder_date", { ascending: true })

    setReminders(data || [])
  }

  const handleAddReminder = async () => {
    if (!formData.title || !formData.reminder_date) {
      return
    }

    setIsLoading(true)
    try {
      const supabase = createClient()
      await supabase.from("reminders").insert({
        ...formData,
        user_id: userId,
      })

      await loadReminders()
      setFormData({
        title: "",
        description: "",
        reminder_date: "",
        reminder_time: "",
        reminder_type: "custom",
      })
      setShowForm(false)
    } finally {
      setIsLoading(false)
    }
  }

  const handleToggleComplete = async (reminderId: string, isCompleted: boolean) => {
    const supabase = createClient()
    await supabase.from("reminders").update({ is_completed: !isCompleted }).eq("id", reminderId)

    await loadReminders()
  }

  const handleDeleteReminder = async (reminderId: string) => {
    const supabase = createClient()
    await supabase.from("reminders").delete().eq("id", reminderId)

    await loadReminders()
  }

  return (
    <div className="space-y-6">
      <Card className="border-primary/20">
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-primary" />
            <div>
              <CardTitle>Your Reminders</CardTitle>
              <CardDescription>Stay on top of important dates and tasks</CardDescription>
            </div>
          </div>
          <Button onClick={() => setShowForm(!showForm)} size="sm" className="bg-primary hover:bg-primary/90">
            {showForm ? "Cancel" : "Add Reminder"}
          </Button>
        </CardHeader>
      </Card>

      {showForm && (
        <Card className="border-primary/20 bg-card">
          <CardHeader>
            <CardTitle>Create New Reminder</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g., Doctor's Appointment"
                  className="bg-background"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="description">Description (optional)</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Add details..."
                  className="bg-background"
                />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="grid gap-2">
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.reminder_date}
                    onChange={(e) => setFormData({ ...formData, reminder_date: e.target.value })}
                    className="bg-background"
                  />
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="time">Time (optional)</Label>
                  <Input
                    id="time"
                    type="time"
                    value={formData.reminder_time}
                    onChange={(e) => setFormData({ ...formData, reminder_time: e.target.value })}
                    className="bg-background"
                  />
                </div>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="type">Type</Label>
                <Select
                  value={formData.reminder_type}
                  onValueChange={(value) => setFormData({ ...formData, reminder_type: value })}
                >
                  <SelectTrigger className="bg-background">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="checkup">Checkup</SelectItem>
                    <SelectItem value="medication">Medication</SelectItem>
                    <SelectItem value="exercise">Exercise</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button
                onClick={handleAddReminder}
                disabled={isLoading || !formData.title || !formData.reminder_date}
                className="w-full bg-primary hover:bg-primary/90"
              >
                {isLoading ? "Creating..." : "Create Reminder"}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-3">
        {reminders.length > 0 ? (
          reminders.map((reminder) => (
            <Card key={reminder.id} className={`border-primary/10 ${reminder.is_completed ? "opacity-60" : ""}`}>
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <Checkbox
                    checked={reminder.is_completed}
                    onCheckedChange={() => handleToggleComplete(reminder.id, reminder.is_completed)}
                    className="mt-1"
                  />

                  <div className="flex-1">
                    <h4
                      className={`font-semibold ${reminder.is_completed ? "line-through text-muted-foreground" : ""}`}
                    >
                      {reminder.title}
                    </h4>
                    {reminder.description && (
                      <p className="text-sm text-muted-foreground mt-1">{reminder.description}</p>
                    )}
                    <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {new Date(reminder.reminder_date).toLocaleDateString()}
                      </div>
                      {reminder.reminder_time && (
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {reminder.reminder_time}
                        </div>
                      )}
                      <div className="capitalize">{reminder.reminder_type}</div>
                    </div>
                  </div>

                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteReminder(reminder.id)}
                    className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <Card className="border-border bg-card">
            <CardContent className="pt-6">
              <p className="text-center text-muted-foreground">No reminders yet. Create one to get started!</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
