"use client"
import { useState } from "react"
import type { User } from "@supabase/supabase-js"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { LogOut, Settings, MessageCircle } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import PregnancyTracker from "./components/pregnancy-tracker"
import PostpartumTracker from "./components/postpartum-tracker"
import HealthTips from "./components/health-tips"
import RemindersSection from "./components/reminders-section"

interface Profile {
  id: string
  email: string
  full_name: string | null
  user_type: "pregnant" | "new_mother"
  avatar_url: string | null
}

interface DashboardClientProps {
  user: User
  profile: Profile
}

export default function DashboardClient({ user, profile }: DashboardClientProps) {
  const [isLoggingOut, setIsLoggingOut] = useState(false)
  const router = useRouter()

  const handleLogout = async () => {
    setIsLoggingOut(true)
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push("/")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card shadow-sm">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Welcome, {profile.full_name || "Mom"}</h1>
              <p className="text-sm text-muted-foreground">
                {profile.user_type === "pregnant" ? "Pregnancy Journey" : "Postpartum Journey"}
              </p>
            </div>
            <div className="flex gap-2">
              <Link href="/ai-assistant">
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <MessageCircle className="h-4 w-4" />
                  AI Assistant
                </Button>
              </Link>
              <Link href="/dashboard/settings">
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <Settings className="h-4 w-4" />
                  Settings
                </Button>
              </Link>
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                disabled={isLoggingOut}
                className="gap-2 bg-transparent"
              >
                <LogOut className="h-4 w-4" />
                {isLoggingOut ? "Logging out..." : "Logout"}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-muted">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="tracking">Tracking</TabsTrigger>
            <TabsTrigger value="tips">Health Tips</TabsTrigger>
            <TabsTrigger value="reminders">Reminders</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6 mt-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card className="border-primary/20">
                <CardHeader>
                  <CardTitle>Quick Stats</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {profile.user_type === "pregnant" ? (
                      <>
                        <div>
                          <p className="text-sm text-muted-foreground">Email</p>
                          <p className="text-lg font-semibold text-foreground">{user.email}</p>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Track your pregnancy progress in the Tracking tab
                        </p>
                      </>
                    ) : (
                      <>
                        <div>
                          <p className="text-sm text-muted-foreground">Email</p>
                          <p className="text-lg font-semibold text-foreground">{user.email}</p>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Track your postpartum recovery in the Tracking tab
                        </p>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-accent/20">
                <CardHeader>
                  <CardTitle>Getting Started</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex gap-2">
                      <span className="text-primary">✓</span>
                      <span>Account created successfully</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="text-muted-foreground">→</span>
                      <span>Add your tracking information</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="text-muted-foreground">→</span>
                      <span>Set up reminders for appointments</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="text-muted-foreground">→</span>
                      <span>Chat with our AI health assistant</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="tracking" className="mt-6">
            {profile.user_type === "pregnant" ? (
              <PregnancyTracker userId={user.id} />
            ) : (
              <PostpartumTracker userId={user.id} />
            )}
          </TabsContent>

          <TabsContent value="tips" className="mt-6">
            <HealthTips userType={profile.user_type} />
          </TabsContent>

          <TabsContent value="reminders" className="mt-6">
            <RemindersSection userId={user.id} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
